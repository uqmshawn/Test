# GitHub Actions Workflows

This directory contains GitHub Actions workflow configurations for automating the build, test, and deployment processes.

## Workflows

### PR Build (`pr-build.yml`)

This workflow runs when a pull request is created against the `main` branch. It performs:

- Code formatting checks with Black
- Code quality checks with Pylint
- Type checking with Mypy
- Runs all tests with pytest

If any of these checks fail, the pull request will be marked as failing, indicating that issues need to be fixed before merging.

### Main Branch Build (`main-build.yml`)

This workflow runs when changes are pushed to the `main` branch (typically after a PR is merged). It:

- Performs all the same code quality checks as the PR workflow
- Builds the Docker image for ARM64 platform
- Pushes the image to DockerHub

## Required Configuration

For the workflows to function properly, configure these in GitHub repository settings:

- **Secret**: `DOCKERHUB_TOKEN` - A DockerHub Personal Access Token
- **Variable**: `DOCKERHUB_USERNAME` - The DockerHub username

## Troubleshooting

If a workflow fails:

1. Check the workflow logs in the GitHub Actions tab of the repository
2. Fix any issues identified in the logs
3. Push the changes to update the pull request
4. The workflow will automatically run again with the new changes
